# MuseScore Parsons Code Exporter
Export a Parsons Code file for a melody line. See https://en.wikipedia.org/wiki/Parsons_code

Usage and more information see: http://musescore.org/en/project/parsonscodeexport
